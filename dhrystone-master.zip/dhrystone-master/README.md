Multiple versions of Reinhold P. Weicker's **Dhrystone** benchmark

Sources downloaded and extracted from old Usenet postings and from
sites linked from http://en.wikipedia.org/wiki/Dhrystone

The `original-sources` directory contains the raw sources.  Each
subdirectory `v1`, `v2.0`, `v2.1`, `v2.2` contains an extracted
version; see the `_README` file in each directory.
